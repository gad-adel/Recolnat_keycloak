package org.recolnat.vault;

import java.util.Optional;

import org.keycloak.vault.DefaultVaultRawSecret;
import org.keycloak.vault.VaultProvider;
import org.keycloak.vault.VaultRawSecret;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class HashicorpVaultProvider implements VaultProvider{
	
   private String vaultUrl;
   private String vaultToken;
   private String realmName;
   private String vaultSecretEngineName;
   private ServiceCallVault service;
   
   public HashicorpVaultProvider(String vaultUrl, String vaultToken, String realmName,
		   String vaultSecretEngineName, ServiceCallVault service) {
      this.vaultUrl = vaultUrl;
      this.vaultToken = vaultToken;
      this.realmName = realmName;
      this.vaultSecretEngineName = vaultSecretEngineName;
      this.service = service;
   }


	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	/**
	 * The vault provider needs to implement a single method obtainSecret that returns a VaultRawSecret
	 *  for the given secret name. 
	 *  That class holds the representation of the secret either in byte[] or ByteBuffer 
	 *  and is expected to convert between the two upon demand.
	 *   Note that this buffer would be discarded after usage as explained below.
	 */
	@Override
	public VaultRawSecret obtainSecret(String arg0) {
		 int secretVersion = 0;
	      String vaultSecretName = arg0;
	      if (arg0.contains(":")) {
	         try {
	            secretVersion = Integer.parseInt(arg0.substring(arg0.lastIndexOf(":") + 1));
	            vaultSecretName = arg0.substring(0, arg0.lastIndexOf(":"));
	         } catch (NumberFormatException e) {
	            log.error("last string after : is expected to be the version number");
	         }
	      }

	     return DefaultVaultRawSecret.forBuffer(
	         Optional.of(
	            service.getSecretFromVault(vaultUrl, realmName, vaultSecretEngineName, 
	            		vaultSecretName, vaultToken, secretVersion)));
	 
	}

}
