package org.recolnat.vault;

import org.keycloak.Config.Scope;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.KeycloakSessionFactory;
import org.keycloak.vault.VaultNotFoundException;
import org.keycloak.vault.VaultProvider;
import org.keycloak.vault.VaultProviderFactory;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class HashicorpVaultProviderFactory implements VaultProviderFactory{
	
	 public static final String PROVIDER_ID = "hachicorp-vault";
	 
	 private String vaultToken;
	 private String vaultUrl;
	 private String vaultSecretEngineName;

	@Override
	public VaultProvider create(KeycloakSession session) {
		ServiceCallVault service = new ServiceCallVault(session);
	      if(!service.isVaultAvailable(vaultUrl, vaultToken)){
	         log.error("Vault unavailable : "+ vaultUrl);
	         throw new VaultNotFoundException("Vault unavailable : "+ vaultUrl);
	      }else{
	         log.info("Vault available : "+ vaultUrl);
	      }
	      return new HashicorpVaultProvider(vaultUrl, vaultToken,
	    		  session.getContext().getRealm().getName(), 
	    		  vaultSecretEngineName, service);

	   }

	/**
	 * recherche le token vault dans l'environnement systeme ou dans la conf
	 * et l url de l api service Vault: <br>
	 * 
	 *    name="token" value="token_value"
	 *    name="url" value="https://vault-url/"
	 *    name="engine-name" value="secret"
	 */
	@Override
	public void init(Scope config) {
		 if(System.getenv("VAULT_TOKEN") != null){
		        vaultToken = System.getenv("VAULT_TOKEN");
		      }else{
		        vaultToken = config.get("token");
		      }
		      if(config.get("url")!=null) {
		    	 if(config.get("url").endsWith("/")) {
		    		 vaultUrl =config.get("url").concat("/");
		    	 }else {
		    		 vaultUrl =config.get("url");
		    	 }
		      }
		      vaultSecretEngineName = config.get("engine-name");
		      log.info("Init Hashicorp: "+ vaultUrl);
	}

	
	@Override
	public void postInit(KeycloakSessionFactory factory) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getId() {
		 return PROVIDER_ID;
	}

}
