package org.recolnat.vault;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import org.keycloak.broker.provider.util.SimpleHttp;
import org.keycloak.models.KeycloakSession;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class ServiceCallVault {
	private KeycloakSession session;

	public ServiceCallVault(KeycloakSession session) {
		this.session = session;
	}
	
	public ByteBuffer getSecretFromVault(String vaultUrl, String realm, String vaultSecretEngineName, String secretName, String vaultToken, int secretVersion) {
		try {
			JsonNode node = SimpleHttp.doGet(vaultUrl + "v1/" + 
						vaultSecretEngineName + "/data/" + realm+ "?version=" +secretVersion, session)
			.header("X-Vault-Token", vaultToken).asJson();
		   byte[] secretBytes = node.get("data").get("data").get(secretName)
				   .textValue().getBytes(StandardCharsets.UTF_8);
			return ByteBuffer.wrap(secretBytes);
		} catch (IOException e) {
			log.error("secret not available", e);
			return null;
		}
	}

	/**
	 * health pour tester si Vault est disponible
	 * et si il est initialized et sealed
	 * @param vaultUrl
	 * @param vaultToken
	 * @return
	 */
	public boolean isVaultAvailable(String vaultUrl, String vaultToken) {
		String healthVaultUrl = vaultUrl + "v1/sys/health";
		try {
			JsonNode vaultHealthResponseNode = SimpleHttp.doGet(healthVaultUrl, session).asJson();
			boolean vaultIsInitialized = vaultHealthResponseNode.get("initialized").asBoolean();
			boolean vaultIsSealed = vaultHealthResponseNode.get("sealed").asBoolean();
			return (vaultIsInitialized && !vaultIsSealed);
		} catch (IOException e) {
			log.error("vault service unavailable", e);
			return false;
		}
	}

}
